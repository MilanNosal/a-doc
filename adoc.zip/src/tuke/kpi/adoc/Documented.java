package tuke.kpi.adoc;

public @interface Documented { }
